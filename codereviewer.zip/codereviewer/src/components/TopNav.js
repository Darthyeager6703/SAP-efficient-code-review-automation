// src/components/TopNav.js
import React from 'react';
import { Link } from 'react-router-dom';

const TopNav = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark" style={{ backgroundColor: '#334155' }}> {/* Updated background color */}
            <div className="container-fluid">
                <Link className="navbar-brand" to="/">CodeReviewer Tool</Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div className="navbar-nav ms-auto"> {/* Align items to the right */}
                        <Link className="nav-link" to="/about">About Us</Link>
                        <Link className="nav-link" to="/contact">Contact Us</Link>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default TopNav;
