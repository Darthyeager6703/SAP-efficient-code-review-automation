# Python3 program to find the next optimal move for a player 
player, opponent = 'x', 'o'

# This function returns true if there are moves 
# remaining on the board. It returns false if 