

const {
  S3, PutObjectCommand
} = require("@aws-sdk/client-s3");

const fs = require('fs');
const {
  CodeGuruReviewer,
  CodeGuruReviewerClient,
  CreateCodeReviewCommand,
  DescribeCodeReviewCommand,
  DescribeRecommendationFeedbackCommand,
  DescribeRepositoryAssociationCommand,
  ListCodeReviewsCommand,
  RepositoryAssociationState
} = require("@aws-sdk/client-codeguru-reviewer");
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const {Octokit} = require("@octokit/rest");
const AdmZip = require('adm-zip');
const glob = require('glob');
const url = require('url');



const app = express();
app.use(cors());
const port = 3001;
const upload = multer({ dest: 'uploads/' });

// Configure AWS with your access and secret key.
const { ACCESS_KEY, SECRET_KEY, BUCKET_NAME } = process.env;

// Configure AWS to use promise

const { createReadStream, createWriteStream } = require('fs');
const archiver = require('archiver');

async function createTempZipFile(fileName, extractedLines) {
    const tempFileName = `temp_${fileName}.zip`;
    const outputFilePath = path.join('.', tempFileName);
    const output = createWriteStream(outputFilePath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    return new Promise((resolve, reject) => {
        output.on('close', () => {
            console.log('Temporary zip file created:', outputFilePath);
            resolve(outputFilePath);
        });

        archive.on('error', (err) => {
            reject(err);
        });

        archive.pipe(output);
        // Append the extracted lines as a file to the zip archive
        archive.append(extractedLines.join('\n'), { name: fileName });
        archive.finalize();
    });
}

app.post('/upload', upload.single('file'), async (req, res) => {
    const file = req.file;
    const { lines } = req.body; 
    console.log('Lines:', typeof lines);

    try {
        if (!file) {
            return res.status(400).json({ error: 'No file uploaded.' });
        }
        // Update the review status to Pending for the new upload
        lastReviewStatus = { state: 'Pending', recommendations: null }; // EXTRA

        const fileName = file.originalname;
        const filePath = 'uploads/' + file.filename;
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        
        if (fileName.endsWith('.zip') ) {
          const s3Response = await uploadToS3(fileName, filePath);
          console.log('Uploaded zip file to S3:', s3Response.Location);

          const codeGuruResponse = await triggerCodeGuruReview(fileName);

          return res.status(200).json({ message: 'Uploaded to S3 and CodeGuru Review triggered.', codeGuruResponse });
      }

        if(lines == 'all lines'){
          const extractedLines = fileContent.split('\n')
          const tempZipFilePath = await createTempZipFile(fileName, extractedLines);

        // Upload the temporary zip file to S3
        const tempFileS3Response = await uploadToS3(tempZipFilePath, tempZipFilePath);
        console.log('uploaded all the lines of file to S3. U can use something like that:', tempFileS3Response.Location);

        // Trigger CodeGuru review on the temporary zip file
        const codeGuruResponse = await triggerCodeGuruReview(tempZipFilePath);

        return res.status(200).json({ message: 'Extracted lines where lines is all lines uploaded to S3, and CodeGuru Review triggered.', codeGuruResponse });

        }
        const lineNumberArray = lines.split(',').map(Number);
        
        const extractedLines = fileContent.split('\n').filter((_, index) => lineNumberArray.includes(index + 1));

        // Create a temporary zip file containing the extracted lines
        const tempZipFilePath = await createTempZipFile(fileName, extractedLines);

        // Upload the temporary zip file to S3
        const tempFileS3Response = await uploadToS3(tempZipFilePath, tempZipFilePath);
        console.log('Uploaded temporary zip file to S3:', tempFileS3Response.Location);

        // Trigger CodeGuru review on the temporary zip file
        const codeGuruResponse = await triggerCodeGuruReview(tempZipFilePath);

        return res.status(200).json({ message: 'Extracted lines uploaded to S3, and CodeGuru Review triggered.', codeGuruResponse });
    } catch (error) {
        console.error('Error processing data:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});

const s3 = new S3({
  credentials: {
    accessKeyId: 'AKIAXYKJWCTNGVYCZGPE',
    secretAccessKey: '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'
  },

  region: 'ap-southeast-1'
});



const codegurureviewer = new CodeGuruReviewer({
  region: 'ap-southeast-1',

  credentials: {
    accessKeyId: 'AKIAXYKJWCTNGVYCZGPE',
    secretAccessKey: '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'
  }
});

const params = {
  Repository: {
    S3Bucket: {
      BucketName: 'codeguru-reviewer-sap-review-3',
      Name: "code-review-input-repository-3"
    }
  }
};

const generateRandomString = () => {
  return crypto.randomBytes(25).toString('hex');
};

function getOwnerAndRepoFromUrl(githubUrl) {
  const path = url.parse(githubUrl).pathname;
  const [_, owner, repo] = path.split('/');
  return { owner, repo };
}

const uploadToS3 = async (fileName, filePath) => {
  const fileContent = await fs.promises.readFile(filePath);

  const params = {
    Bucket: 'codeguru-reviewer-sap-review-3',
    Key: `code-review-input-repository-3/${fileName}`,
    Body: fileContent
  };

  return s3.send(new PutObjectCommand(params));
};

// First, associate the repository
async function associateRepository() {
  const params = {
    Repository: {
      S3Bucket: {
        BucketName: 'codeguru-reviewer-sap-review-3',
        Name: "code-review-input-repository-3"
      }
    }
  };
  return codegurureviewer.associateRepository(params);
}




async function CreateCodeReview(codeReviewparams) {
  return codegurureviewer.createCodeReview(codeReviewparams);

}

async function checkCodeReviewStatus(codeReviewArn) {
  const describe_params = {
    CodeReviewArn: codeReviewArn
  };
  return codegurureviewer.describeCodeReview(describe_params);
}
// Global object to store the review status
let lastReviewStatus = {};

const triggerCodeGuruReview = async (FileName) => {
  const codeReviewparams = {
    Name: generateRandomString(),
    RepositoryAssociationArn: 'arn:aws:codeguru-reviewer:ap-southeast-1:533267354842:association:fbb3515e-a9c6-4d03-a34e-586236990dcd',
    Type: {
      AnalysisTypes: ["Security", "CodeQuality"],
      RepositoryAnalysis: {
        S3BucketRepository: {
          Name: "code-review-input-repository-3",
          Details: {
            BucketName: "codeguru-reviewer-sap-review-3",
            CodeArtifacts: {
              SourceCodeArtifactsObjectKey: `code-review-input-repository-3/${FileName}`
            }
          }
        }
      }
    }
  };

  CreateCodeReview(codeReviewparams)
    .then(response => {
      console.log(response);
      const codeReviewArn = response.CodeReview.CodeReviewArn;

      const intervalId = setInterval(() => {
        checkCodeReviewStatus(codeReviewArn)
          .then(response => {
            console.log(response.CodeReview.State);
            lastReviewStatus = { state: response.CodeReview.State };

            if (response.CodeReview.State === 'Completed') {
              clearInterval(intervalId);
              console.log('Code review completed');
              codegurureviewer.listRecommendations({ CodeReviewArn: codeReviewArn })
                .then(recommendationsResponse => {
                  console.log(recommendationsResponse);
                  lastReviewStatus.recommendations = recommendationsResponse.RecommendationSummaries;
                })
                .catch(console.error);
            }
          })
          .catch(console.error);
      }, 60000); // Check every 60 seconds
    })
    .catch(console.error);
};

// Endpoint to get the latest review status
app.get('/review-status', (req, res) => {
  if (lastReviewStatus.state) {
    res.json(lastReviewStatus);
  } else {
    res.status(404).json({ message: 'Review status not found' });
  }
});


app.use(express.json());





app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

